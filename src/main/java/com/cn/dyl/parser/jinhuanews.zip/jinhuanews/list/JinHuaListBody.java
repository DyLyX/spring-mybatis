package com.cn.dyl.parser.jinhuanews.list;

import java.util.List;

public class JinHuaListBody {
	private List<JinHuaListItem> data;
	
	public List<JinHuaListItem> getData() {
		return data;
	}

	public void setData(List<JinHuaListItem> data) {
		this.data = data;
	}
}
